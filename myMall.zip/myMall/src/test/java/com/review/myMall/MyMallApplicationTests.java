package com.review.myMall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyMallApplicationTests {

	@Test
	void contextLoads() {
	}

}
